#!/bin/sh
echo "This is the contents of stdout."
echo "This is the contents of stderr." 1>&2
