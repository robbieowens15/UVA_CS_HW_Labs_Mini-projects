#!/bin/sh
read firstLine
read secondLine
echo "Line 1: $firstLine"
echo "Line 2: $secondLine"
