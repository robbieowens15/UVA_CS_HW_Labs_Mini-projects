#!/bin/sh

echo ""
echo "number of arguments: $#"
echo "argument 1: $1"
echo "argument 2: $2"
echo "argument 3: $3"
echo "argument 4: $4"
