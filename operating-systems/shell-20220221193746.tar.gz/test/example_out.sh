#!/bin/sh
echo foo bar baz
