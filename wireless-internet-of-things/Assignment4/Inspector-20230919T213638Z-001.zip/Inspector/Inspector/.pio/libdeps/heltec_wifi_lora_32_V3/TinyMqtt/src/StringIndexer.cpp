#include "StringIndexer.h"

std::map<StringIndexer::index_t, StringIndexer::StringCounter> StringIndexer::strings;
