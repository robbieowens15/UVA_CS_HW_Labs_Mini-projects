public class Source extends Vertex {
    public Source(){
        super("Source");
    }
}
