public class Sink extends Vertex{
    public Sink(){
        super("Sink");
    }
}
