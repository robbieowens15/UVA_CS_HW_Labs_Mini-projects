public class Student extends Vertex{
    public static int limit;

    public Student(String name) {
        super(name);
    }
}
