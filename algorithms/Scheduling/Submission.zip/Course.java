public class Course extends Vertex {
    public int limit;

    public Course(String name){
        super(name);
    }
}
